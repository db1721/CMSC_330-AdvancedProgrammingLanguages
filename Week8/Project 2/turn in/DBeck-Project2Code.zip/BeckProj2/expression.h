class Expression
{
public:
    //changed type to int
   virtual int evaluate() = 0;
};
